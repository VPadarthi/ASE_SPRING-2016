package pack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/**
 * Servlet implementation class Display_Data
 */
@WebServlet("/display")
public class Display_Data extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display_Data() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("IN POST METHOD>>>>>>>>>>>>>>>>>>>>>");
		PrintWriter var=response.getWriter();
		response.setContentType("text/plain");
		MongoClientURI uri  = new MongoClientURI("mongodb://vikesh:Kiran86@ds045598.mlab.com:45598/assignment6"); 
	    MongoClient client = new MongoClient(uri);
	    DB db = client.getDB(uri.getDatabase());
	    System.out.println("Sysy"+db.getName());
	    DBCollection users = db.getCollection("lab6");
	    //Adding new code..................................................
	    BasicDBObject query = new BasicDBObject();
	    BasicDBObject field = new BasicDBObject();
	    field.put("cityname", "Madison");
	    DBCursor cursor = db.getCollection("lab6").find(query,field);
	    var.println("List Of Cities Available");
	    int i=1;
	    while (cursor.hasNext()) {
	        BasicDBObject obj = (BasicDBObject) cursor.next();
	        System.out.println("City Name"+obj.getString("cityname"));
	        var.println(i+")"+""+obj.getString("cityname"));
	        i++;
	        
	       // result.add(obj.getString("HomeTown"));
	    }
	    /*BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("cityname", "kansas");
		DBCursor cursor = users.find(whereQuery);
		System.out.println("Before while");
		while(cursor.hasNext()) {
			System.out.println("inside while condition..........");
		    System.out.println(cursor.next());
		}*/
		System.out.println("After while condition...................");
	}
	@Override
	protected void doOptions(HttpServletRequest arg0, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doOptions(arg0, response);

		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, HEAD, OPTIONS");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type");
		response.setHeader("Access-Control-Max-Age", "86400");
	}

}
