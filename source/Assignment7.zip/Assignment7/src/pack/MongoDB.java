package pack;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;

public class MongoDB {
public static void main(String[] args) {

    MongoClientURI uri  = new MongoClientURI("mongodb://vikesh:Kiran86@ds045598.mlab.com:45598/assignment6"); 
    MongoClient client = new MongoClient(uri);
    DB db = client.getDB(uri.getDatabase());
    System.out.println("Sysy"+db.getName());
    DBCollection users = db.getCollection("lab6");
    String abc="abc";
    DBObject dbObject = (DBObject)JSON.parse(abc);
    users.insert(dbObject);
		
}
}
