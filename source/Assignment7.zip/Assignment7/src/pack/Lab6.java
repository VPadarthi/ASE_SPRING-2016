package pack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/**
 * Servlet implementation class Lab6
 */
@WebServlet("/loginServlet")
public class Lab6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Lab6() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 MongoClientURI uri  = new MongoClientURI("mongodb://vikesh:Kiran86@ds045598.mlab.com:45598/assignment6"); 
		    MongoClient client = new MongoClient(uri);
		    DB db = client.getDB(uri.getDatabase());
		    System.out.println("Sysy"+db.getName());
		    DBCollection users = db.getCollection("lab6");
		    
		    String source = request.getParameter("username");
	        String destination = request.getParameter("password");
	        String api="http://api.openweathermap.org/data/2.5/weather?q="+source+"&APPID=68d31f0454905cbf6357da222b09baff&mode=json";
	 		//String api1="http://api.openweathermap.org/data/2.5/weather?q="+destination+"&APPID=68d31f0454905cbf6357da222b09baff&mode=json";
	 		URL url = new URL(api);
	 		//URL url1 = new URL(api1);
	 		String abd=url.toString();
	 		String vc=callURL(abd);
	 		try {
				JSONObject jsonObject  = new JSONObject(vc);
				String firstinsert=jsonObject.toString();
			 	//To insert data...................................................
		 //	DBObject dbObject = (DBObject)JSON.parse(firstinsert);
	  // users.insert(dbObject);
			    //To retrieve data from MongoDB.......................................
			    System.out.println("Retrieved data from MongoDb");
			    DBCursor cursorDoc = users.find();  
			    while (cursorDoc.hasNext()) {  
			     System.out.println(cursorDoc.next());  
			    }
				
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 		
	 		//String abd1=url1.toString();
	 		
		    
		//doGet(request, response);
	}
	public static String callURL(String myURL) {
		//System.out.println("Requeted URL:" + myURL);
		StringBuilder sb = new StringBuilder();
		URLConnection urlConn = null;
		InputStreamReader in = null;
		try {
			URL url = new URL(myURL);
			urlConn = url.openConnection();
			if (urlConn != null)
				urlConn.setReadTimeout(60 * 1000);
			if (urlConn != null && urlConn.getInputStream() != null) {
				in = new InputStreamReader(urlConn.getInputStream(),
						Charset.defaultCharset());
				BufferedReader bufferedReader = new BufferedReader(in);
				if(bufferedReader!=null)
				{
					int cp;
					while ((cp = bufferedReader.read()) != -1) {
						sb.append((char) cp);
					}
					bufferedReader.close();
				}
			}
		in.close();
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling URL:"+ myURL, e);
		} 
 
		return sb.toString();
				}
	
}


