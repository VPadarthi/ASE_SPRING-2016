package com.example.vikesh.assignment_2;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class SignUp_Page extends AppCompatActivity {
    private static int RESULT_LOAD_IMG = 1;
    String imgDecodableString;
    public EditText firstname,lastName,phone;
    Button bn;
    int request=1;
    ImageView img1;
    Bitmap BMP; // added on feb 10 8pm

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up__page);
        firstname=(EditText)findViewById(R.id.first_Name);
        lastName=(EditText)findViewById(R.id.last_Name);
        phone=(EditText)findViewById(R.id.phone);
        bn=(Button)findViewById(R.id.buttonCamera);
        img1=(ImageView)findViewById(R.id.imgView);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(i.resolveActivity(getPackageManager())!=null)
                {
                    startActivityForResult(i,request);

                }

            }
        }); // Added for camera

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    public void loadImagefromGallery(View view) {
        // Create intent to Open Image applications like Gallery, Google Photos
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        // Start the Intent
        startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
    }
    public void onClickSignUp(View v)
    {
        if((firstname.getText().toString().isEmpty()||lastName.getText().toString().isEmpty()||phone.getText().toString().isEmpty()))
        {
            //startActivity(new Intent(this, SignUp_Successfull.class));
            Toast.makeText(getApplicationContext(), "Please fill all details", Toast.LENGTH_LONG).show();
        } else
        {
            Intent intent=new Intent(this,MapsActivity.class); // added feb 10 8pm
            intent.putExtra("Image", BMP);  //  added feb 10 8pm
            startActivity(intent);  //  added feb 10 8pm
          //  startActivity(new Intent(this, MapsActivity.class));
            //Toast.makeText(getApplicationContext(), "Wrong Details", Toast.LENGTH_LONG).show();
        }

    }
  /*  public void cameraAction(View v)
    {
        Log.d("class was called","class");
        startActivity(new Intent(this, Camera.class));
    }*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            // When an Image is picked
            if (requestCode == RESULT_LOAD_IMG && resultCode == RESULT_OK
                    && null != data) {
                // Get the Image from data
                Uri selectedImage = data.getData();
                String[] filePathColumn = { MediaStore.Images.Media.DATA };
                // Get the cursor
                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                // Move to first row
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                imgDecodableString = cursor.getString(columnIndex);
                cursor.close();
                ImageView imgView;
                //BMP=BitmapFactory.decodeFile(String.valueOf(filePathColumn)); // added feb 10 8pm
                imgView= (ImageView) findViewById(R.id.imgView);
                // Set the Image in ImageView after decoding the String
                imgView.setImageBitmap(BitmapFactory
                        .decodeFile(imgDecodableString));
                BMP=BitmapFactory
                        .decodeFile(imgDecodableString);

            }
            else {
                Bundle bundle = new Bundle();
                bundle = data.getExtras();
                //Bitmap BMP;
                BMP = (Bitmap) bundle.get("data");
                Log.d("DATA", BMP.toString());
                img1.setImageBitmap(BMP);
            }
            /*
            {
                Toast.makeText(this, "You haven't picked Image",
                        Toast.LENGTH_LONG).show();
            }
*/
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }

    }

}
